#!/bin/bash

echo Installing Node Js 
echo As fast as we can
# Add the Node.js repository and update package lists
#curl -sL https://deb.nodesource.com/setup_20.x | sudo -E bash -

# Install Node.js and npm
#sudo apt-get install -y nodejs

# Verify the installation
node -v
npm -v
